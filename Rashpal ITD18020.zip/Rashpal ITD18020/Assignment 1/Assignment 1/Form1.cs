﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_1
{
    public partial class Form1 : Form
    {
        string[,] array = new string[5, 3];
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void button21_Click_1(object sender, EventArgs e)
        {
            if (array[0, 0] == "A0")
            {
                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[0, 0] + " is booked.";
            }
            else if (array[0, 1] == "A1")
            {
                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[0, 1] + " is booked.";
            }
            else if (array[0, 2] == "A2")
            {
                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[0, 2] + " is booked.";
            }
            else if (array[1, 0] == "B0")
            {
                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[1, 0] + " is booked.";
            }
            else if (array[1, 1] == "B1")
            {
                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[1, 1] + " is booked.";
            }
            else if (array[1, 2] == "B2")
            {
                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[1, 2] + " is booked.";
            }
            else if (array[2, 0] == "C0")
            {
                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[2, 0] + " is booked.";
            }
            else if (array[2, 1] == "C1")
            {
                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[2, 1] + " is booked.";
            }
            else if (array[2, 2] == "C2")
            {
                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[2, 2] + " is booked.";
            }
            else if (array[3, 0] == "D0")
            {
                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[3, 0] + " is booked.";
            }
            else if (array[3, 1] == "D1")
            {
                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[3, 1] + " is booked.";
            }
            else if (array[3, 2] == "D2")
            {
                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[3, 2] + " is booked.";
            }
            else if (array[4, 0] == "E0")
            {
                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[4, 0] + " is booked.";
            }
            else if (array[4, 1] == "E1")
            {
                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[4, 1] + " is booked.";
            }
            else if (array[4, 2] == "E2")
            {
                richTextBox1.Text = "Seat " + array[4, 2] + " is booked.";
                richTextBox2.Text = "";
            }
        }

        private void button18_Click_1(object sender, EventArgs e)
        {
            string abc = textBox1.Text;


            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 0)
            {
                array[0, 0] = "A0";
                MessageBox.Show("Seat is booked for " + abc);
                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[0, 0] + " is booked for " + abc;

            }
            else if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 1)
            {
                array[0, 1] = "A1";
                MessageBox.Show("Seat is booked for " + abc);

                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[0, 1] + " is booked for " + abc;

            }
            else if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 2)
            {
                array[0, 2] = "A2";
                MessageBox.Show("Seat is booked for " + abc);

                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[0, 2] + " is booked for " + abc;

            }
            else if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 0)
            {
                array[1, 0] = "B0";
                MessageBox.Show("Seat is booked for " + abc);

                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[1, 0] + " is booked for " + abc;

            }
            else if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 1)
            {
                array[1, 1] = "B1";
                MessageBox.Show("Seat is booked for " + abc);

                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[1, 1] + " is booked for " + abc;

            }
            else if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 2)
            {
                array[1, 2] = "B2";
                MessageBox.Show("Seat is booked for " + abc);

                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[1, 2] + " is booked for " + abc;

            }
            else if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 0)
            {
                array[2, 0] = "C0";
                MessageBox.Show("Seat is booked for " + abc);

                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[2, 0] + " is booked for " + abc;

            }
            else if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 1)
            {
                array[2, 1] = "C1";
                MessageBox.Show("Seat is booked for " + abc);

                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[2, 1] + " is booked for " + abc;

            }
            else if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 2)
            {
                array[2, 2] = "C2";
                MessageBox.Show("Seat is booked for " + abc);

                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[2, 2] + " is booked for " + abc;

            }
            else if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 0)
            {
                array[3, 0] = "D0";
                MessageBox.Show("Seat is booked for " + abc);

                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[3, 0] + " is booked for " + abc;

            }
            else if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 1)
            {
                array[3, 1] = "D1";
                MessageBox.Show("Seat is booked for " + abc);

                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[3, 1] + " is booked for " + abc;

            }
            else if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 2)
            {
                array[3, 2] = "D2";
                MessageBox.Show("Seat is booked for " + abc);

                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[3, 2] + " is booked for " + abc;

            }
            else if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 0)
            {
                array[4, 0] = "E0";
                MessageBox.Show("Seat is booked for " + abc);

                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[4, 0] + " is booked for " + abc;

            }
            else if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 1)
            {
                array[4, 1] = "E1";
                MessageBox.Show("Seat is booked for " + abc);

                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[4, 1] + " is booked for " + abc;

            }
            else if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 2)
            {
                array[4, 2] = "E2";
                MessageBox.Show("Seat is booked for " + abc);

                richTextBox2.Text = "";
                richTextBox1.Text = "Seat " + array[4, 2] + " is booked for " + abc;

            }
        }

        private void button17_Click_1(object sender, EventArgs e)
        {
            string name = textBox1.Text;

            if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 0)
            {
                array[0, 0] = "";
                MessageBox.Show("Seat is canceled for " + name);
                richTextBox1.Text = "Seat " + array[0, 0] + " is canceled for " + name;
            }

            else if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 1)
            {
                array[0, 1] = "";
                richTextBox1.Text = "Seat " + array[0, 1] + " is canceled for " + name;
                MessageBox.Show("Seat is canceled for " + name);
            }
            else if (listBox1.SelectedIndex == 0 && listBox2.SelectedIndex == 2)
            {
                array[0, 2] = "";
                richTextBox1.Text = "Seat " + array[0, 2] + " is canceled for " + name;
                MessageBox.Show("Seat is canceled for " + name);
            }
            else if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 0)
            {
                array[1, 0] = "";
                richTextBox1.Text = "Seat " + array[1, 0] + " is canceled for " + name;
                MessageBox.Show("Seat is canceled for " + name);
            }
            else if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 1)
            {
                array[1, 1] = "";
                richTextBox1.Text = "Seat " + array[1, 1] + " is canceled for " + name;
                MessageBox.Show("Seat is canceled for " + name);
            }
            else if (listBox1.SelectedIndex == 1 && listBox2.SelectedIndex == 2)
            {
                array[1, 2] = "";
                richTextBox1.Text = "Seat " + array[1, 2] + " is canceled for " + name;
                MessageBox.Show("Seat is canceled for " + name);
            }
            else if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 0)
            {
                array[2, 0] = "";
                richTextBox1.Text = "Seat " + array[2, 0] + " is canceled for " + name;
                MessageBox.Show("Seat is canceled for " + name);
            }
            else if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 1)
            {
                array[2, 1] = "";
                richTextBox1.Text = "Seat " + array[2, 1] + " is canceled for " + name;
                MessageBox.Show("Seat is canceled for " + name);
            }
            else if (listBox1.SelectedIndex == 2 && listBox2.SelectedIndex == 2)
            {
                array[2, 2] = "";
                richTextBox1.Text = "Seat " + array[2, 2] + " is canceled for " + name;
                MessageBox.Show("Seat is canceled for " + name);
            }
            else if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 0)
            {
                array[3, 0] = "";
                richTextBox1.Text = "Seat " + array[3, 0] + " is canceled for " + name;
                MessageBox.Show("Seat is canceled for " + name);
            }
            else if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 1)
            {
                array[3, 1] = "";
                richTextBox1.Text = "Seat " + array[3, 1] + " is canceled for " + name;
                MessageBox.Show("Seat is canceled for " + name);
            }
            else if (listBox1.SelectedIndex == 3 && listBox2.SelectedIndex == 2)
            {
                array[3, 2] = "";
                richTextBox1.Text = "Seat " + array[3, 2] + " is canceled for " + name;
                MessageBox.Show("Seat is canceled for " + name);
            }
            else if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 0)
            {
                array[4, 0] = "";
                richTextBox1.Text = "Seat " + array[4, 0] + " is canceled for " + name;
                MessageBox.Show("Seat is canceled for " + name);
            }
            else if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 1)
            {
                array[4, 1] = "";
                richTextBox1.Text = "Seat " + array[4, 1] + " is canceled for " + name;
                MessageBox.Show("Seat is canceled for " + name);
            }
            else if (listBox1.SelectedIndex == 4 && listBox2.SelectedIndex == 2)
            {
                array[4, 2] = "";
                richTextBox1.Text = "Seat " + array[4, 2] + " is canceled for " + name;
                MessageBox.Show("Seat is canceled for " + name);

            }
            else
            {
                MessageBox.Show("Please fill the name & select the seat you want to cancel.");
            }
        }

        private void button22_Click_1(object sender, EventArgs e)
        {

        }

        private void button16_Click_1(object sender, EventArgs e)
        {
            if (array[0, 0] == "A0")
            {
                textBox2.Text = "Not available";
            }
            else if (array[0, 1] == "A1")
            {
                textBox2.Text = "Not available";
            }
            else if (array[0, 2] == "A2")
            {
                textBox2.Text = "Not available";
            }
            else if (array[1, 0] == "B0")
            {
                textBox2.Text = "Not available";
            }
            else if (array[1, 1] == "B1")
            {
                textBox2.Text = "Not available";
            }
            else if (array[1, 2] == "B2")
            {
                textBox2.Text = "Not available";
            }
            else if (array[2, 0] == "C0")
            {
                textBox2.Text = "Not available";
            }
            else if (array[2, 1] == "C1")
            {
                textBox2.Text = "Not available";
            }
            else if (array[2, 2] == "C2")
            {
                textBox2.Text = "Not available";
            }
            else if (array[3, 0] == "D0")
            {
                textBox2.Text = "Not available";
            }
            else if (array[3, 1] == "D1")
            {
                textBox2.Text = "Not available";
            }
            else if (array[3, 2] == "D2")
            {
                textBox2.Text = "Not available";
            }
            else if (array[4, 0] == "E0")
            {
                textBox2.Text = "Not available";
            }
            else if (array[4, 1] == "E1")
            {
                textBox2.Text = "Not available";
            }
            else if (array[4, 2] == "E2")
            {
                textBox2.Text = "Not available";
            }


            else if (array[0, 0] == "")
            {
                textBox2.Text = "Available";
            }
            else if (array[0, 1] == "")
            {
                textBox2.Text = "Available";
            }
            else if (array[0, 2] == "")
            {
                textBox2.Text = "Available";
            }
            else if (array[1, 0] == "")
            {
                textBox2.Text = "Available";
            }
            else if (array[1, 1] == "")
            {
                textBox2.Text = "Available";
            }
            else if (array[1, 2] == "")
            {
                textBox2.Text = "Available";
            }
            else if (array[2, 0] == "")
            {
                textBox2.Text = "Available";
            }
            else if (array[2, 1] == "")
            {
                textBox2.Text = "Available";
            }
            else if (array[2, 2] == "")
            {
                textBox2.Text = "Available";
            }
            else if (array[3, 0] == "")
            {
                textBox2.Text = "Available";
            }
            else if (array[3, 1] == "")
            {
                textBox2.Text = "Available";
            }
            else if (array[3, 2] == "")
            {
                textBox2.Text = "Available";
            }
            else if (array[4, 0] == "")
            {
                textBox2.Text = "Available";
            }
            else if (array[4, 1] == "")
            {
                textBox2.Text = "Available";
            }
            else if (array[4, 2] == "")
            {
                textBox2.Text = "Available";
            }
        }

        private void button19_Click_1(object sender, EventArgs e)
        {
            string abc = textBox1.Text;


            if (array[0, 0] == "A0")
            {
                array[0, 0] = "";
                richTextBox1.Text = "";
                richTextBox2.Text = abc + " is added to the waiting list.";
            }
            else if (array[0, 1] == "A1")
            {
                array[0, 1] = "";
                richTextBox1.Text = "";
                richTextBox2.Text = abc + " is added to the waiting list.";
            }
            else if (array[0, 2] == "A2")
            {
                array[0, 2] = "";
                richTextBox1.Text = "";
                richTextBox2.Text = abc + " is added to the waiting list.";
            }
            else if (array[1, 0] == "B0")
            {
                array[1, 0] = "";
                richTextBox1.Text = "";
                richTextBox2.Text = abc + " is added to the waiting list.";
            }
            else if (array[1, 1] == "B1")
            {
                array[1, 1] = "";
                richTextBox1.Text = "";
                richTextBox2.Text = abc + " is added to the waiting list.";
            }
            else if (array[1, 2] == "B2")
            {
                array[1, 2] = "";
                richTextBox1.Text = "";
                richTextBox2.Text = abc + " is added to the waiting list.";
            }
            else if (array[2, 0] == "C0")
            {
                array[2, 0] = "";
                richTextBox1.Text = "";
                richTextBox2.Text = abc + " is added to the waiting list.";
            }
            else if (array[2, 1] == "C1")
            {
                array[2, 1] = "";
                richTextBox1.Text = "";
                richTextBox2.Text = abc + " is added to the waiting list.";
            }
            else if (array[2, 2] == "C2")
            {
                array[2, 2] = "";
                richTextBox1.Text = "";
                richTextBox2.Text = abc + " is added to the waiting list.";
            }
            else if (array[3, 0] == "D0")
            {
                array[3, 0] = "";
                richTextBox1.Text = "";
                richTextBox2.Text = abc + " is added to the waiting list.";
            }
            else if (array[3, 1] == "D1")
            {
                array[3, 1] = "";
                richTextBox1.Text = "";
                richTextBox2.Text = abc + " is added to the waiting list.";
            }
            else if (array[3, 2] == "D2")
            {
                array[3, 2] = "";
                richTextBox2.Text = abc + " is added to the waiting list.";
                richTextBox1.Text = "";
            }
            else if (array[4, 0] == "E0")
            {
                array[4, 0] = "";
                richTextBox2.Text = abc + " is added to the waiting list.";
                richTextBox1.Text = "";
            }
            else if (array[4, 1] == "E1")
            {
                array[4, 1] = "";
                richTextBox2.Text = abc + " is added to the waiting list.";
                richTextBox1.Text = "";
            }
            else if (array[4, 2] == "E2")
            {
                array[4, 2] = "";
                richTextBox2.Text = abc + " is added to the waiting list.";
                richTextBox1.Text = "";
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {

        } 
    }
}
